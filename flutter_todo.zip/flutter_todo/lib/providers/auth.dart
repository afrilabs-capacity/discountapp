import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

import 'package:flutter_todo/widgets/notification_text.dart';

enum Status { Uninitialized, Authenticated, Authenticating, Unauthenticated }

class AuthProvider with ChangeNotifier {

  Status _status = Status.Uninitialized;
  String _token;
  NotificationText _notification;

  Status get status => _status;
  String get token => _token;
  NotificationText get notification => _notification;

  final String api = 'http://192.168.43.122:8080/laravel/site43/public/api/v1/auth';

  initAuthProvider() async {
    String token = await getToken();
    if (token != null) {
      _token = token;
      _status = Status.Authenticated;
    } else {
      _status = Status.Unauthenticated;
    }

    //print(_status);
    notifyListeners();
  }

  Future<bool> login(String email, String password) async {
    _status = Status.Authenticating;
    _notification = null;
    notifyListeners();

    await Future.delayed(const Duration(milliseconds: 5000), () {});

    final url = "$api/login";

    Map<String, String> body = {
      'email': email,
      'password': password,
    };

    final response = await http.post(url, body: body,);

    if (response.statusCode == 200) {
      print('authenticated in login providr');
      Map<String, dynamic> apiResponse = json.decode(response.body);
      _status = Status.Authenticated;
      _token = apiResponse['access_token'];
      await storeUserData(apiResponse);
      notifyListeners();
      return true;
    }

    if (response.statusCode == 401) {
      print('unauthenticated in login providr');
      _status = Status.Unauthenticated;
      _notification = NotificationText('Invalid email or password.');
      notifyListeners();
      return false;
    }

    _status = Status.Unauthenticated;
    //print('unauthenticated in login providr below 401');
    _notification = NotificationText('Server error.');
    notifyListeners();
    return false;
  }

  Future<Map> register(
    String titleController, String firstNameController, String middleNameController, String lastNameController, String addressController, String sexController, String cityController, String stateController, String dobController, String idTypeController, String idNumberController, String emailController, String phoneController, String regTypeController, String instituteSchoolController, String matriculationExamNumberController, String levelExpectedGraduationYearController, String passwordController, String passwordConfirmController
  ) async {
    final url = "$api/register";

    Map<String, String> body = {
   'title':titleController,
   'first_name':firstNameController,
   'middle_name':middleNameController,
   'last_name':lastNameController,
   'address':addressController,
    'sex':sexController,
    'city':cityController,
    'state':stateController,
    'dob':dobController,
    'id_type':idTypeController,
    'id_number':idNumberController,
    'email':emailController,
    'phone':phoneController,
    'reg_type':regTypeController,
    'institute_school':instituteSchoolController,
    'mat_exam_num':matriculationExamNumberController,
    'level_expected_grauation_year':levelExpectedGraduationYearController,
      'password': passwordController,
      'password_confirmation': passwordConfirmController,
    };


    Map<String, dynamic> result = {
      "success": false,
      "message": 'Unknown error.',
      "errors":null
    };

    var headers = {
      "Accept": "application/json"
    };

    try{

    final response = await http.post( url, headers: headers , body:body);

    //print(response.body);
    Map apiResponse = json.decode(response.body);


    print(response.body);
    if (response.statusCode == 200) {
      _notification = NotificationText('Registration successful, please log in.', type: 'info');
      _status = Status.Authenticated;
      _token = apiResponse['access_token'];
      await storeUserData(apiResponse);
      print(apiResponse);
      notifyListeners();
      result['message']="Registration successful";
      result['success'] = true;
      return result;
    }



    if (response.statusCode == 422) {
//      if (apiResponse['errors'].containsKey('email')) {
//        result['message'] = apiResponse['errors']['email'][0];
//        return result;
//      }
//      if (apiResponse['errors'].containsKey('email')) {
//        result['message'] = apiResponse['errors']['email'][0];
//        return result;
//      }

//      if (apiResponse['errors'].containsKey('password')) {
//        result['message'] = apiResponse['errors']['password'][0];
//        return result;
//      }
      result['errors']=apiResponse['errors'];

      return result;
    }

    return result;
  }
    catch(e){
      //result['message']='We\'re experiencing technical difficulties, please try again later';
      result['message']=e.toString();
      result['success']=false;
      return result;
    }

  }


  Future<bool> passwordReset(String email) async {
    final url = "$api/forgot-password";

    Map<String, String> body = {
      'email': email,
    };

    final response = await http.post( url, body: body, );

    if (response.statusCode == 200) {
      _notification = NotificationText('Reset sent. Please check your inbox.', type: 'info');
      notifyListeners();
      return true;
    }

    return false;
  }

  storeUserData(apiResponse) async {
    SharedPreferences storage = await SharedPreferences.getInstance();
    await storage.setString('token', apiResponse['access_token']);
    await storage.setString('name', apiResponse['user']['name']);
  }

  Future<String> getToken() async {
    SharedPreferences storage = await SharedPreferences.getInstance();
    String token = storage.getString('token');
    return token;
  }

  logOut([bool tokenExpired = false]) async {
    _status = Status.Unauthenticated;
    if (tokenExpired == true) {
      _notification = NotificationText('Session expired. Please log in again.', type: 'info');
    }
    notifyListeners();

    SharedPreferences storage = await SharedPreferences.getInstance();
    await storage.clear();
  }

}