import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';


class UserProvider extends ChangeNotifier{

String test ="hey";

Future<void> saveUserAvatar(String image) async{
    SharedPreferences storage = await SharedPreferences.getInstance();
    await storage.setString('image', image);
    //notifyListeners();
  }

  Future<String> getUserAvatar() async {
    SharedPreferences storage = await SharedPreferences.getInstance();
    String image = storage.getString('image');
    return image;
  }

Future<String> getUserName() async {
  SharedPreferences storage = await SharedPreferences.getInstance();
  String name= storage.getString('name');
  //notifyListeners();
  return name;
}

  changeString(String string){
    test=string;
   //notifyListeners();
    //return _test;


  }



}