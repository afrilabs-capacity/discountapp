import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:flutter_todo/providers/auth.dart';
import 'package:flutter_todo/providers/user.dart';

import 'package:flutter_todo/views/loading.dart';
import 'package:flutter_todo/views/login.dart';
import 'package:flutter_todo/views/register.dart';
import 'package:flutter_todo/views/password_reset.dart';
import 'package:flutter_todo/views/todos.dart';
import 'package:flutter/services.dart';
import 'views/registration_type.dart';
import 'package:flutter_todo/views/student_registration.dart';
import 'package:flutter_todo/views/upload.dart';

void main() {

  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp])
      .then((_) {
   // runApp(new MyApp());
    runApp(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<AuthProvider>(builder: (context) => AuthProvider()),
          ChangeNotifierProvider<UserProvider>(builder: (context) => UserProvider()),
        ],
        //builder: (context) => AuthProvider(),
        child: MaterialApp(
          //initialRoute: MyCustomForm.id,
          routes: {
           '/': (context) => Router(),
            Login.id: (context) => Login (),
            '/register': (context) => Register(),
            RegistrationType.id: (context) => RegistrationType(),
            StudentRegistration.id: (context) => StudentRegistration(),
            '/password-reset': (context) => PasswordReset(),
          },
        ),
      ),
    );



  });

}

class Router extends StatelessWidget {

  static final id = 'Router';

  @override
  Widget build(BuildContext context) {

    final authProvider = Provider.of<AuthProvider>(context);

    print(authProvider.status);

        switch (authProvider.status) {
          case Status.Uninitialized:
            return Loading();
          case Status.Unauthenticated:
            return Login ();
          case Status.Authenticated:
            return UploadPassport();
          default:
            return Login ();
        }


  }




}