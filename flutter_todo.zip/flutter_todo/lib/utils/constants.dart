import 'package:flutter/material.dart';

const siteUrl="http://192.168.43.122:8080/laravel/site43/public";