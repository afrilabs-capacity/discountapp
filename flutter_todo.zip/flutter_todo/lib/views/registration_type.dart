import 'package:flutter/material.dart';
import 'package:flutter_todo/components/green_round_button.dart';
import 'package:flutter_todo/components/curved_page_template.dart';
import 'package:flutter_todo/views/student_registration.dart';

class RegistrationType extends StatefulWidget {
  static final id = 'registration_type';
  @override
  _RegistrationTypeState createState() => _RegistrationTypeState();
}

class _RegistrationTypeState extends State<RegistrationType> {


  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      //backgroundColor: Color(0xFF21BFBD),
      backgroundColor: Colors.green,
      //backgroundColor: Color(0xEEE),
//      appBar: AppBar(
//        title: const Text('Go Back',style: TextStyle(color: Colors.green),),
//        iconTheme: IconThemeData(color: Colors.green),
//        backgroundColor: Colors.white,
//
//      ),
     body: Container(
        //color: Colors.white,
          child: CurvedPageTemplate( titleBold: 'Card', titleLight: 'Type',  curvedChild: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              SizedBox(height: 80.0,),
              Center(
                child:Container(
                    child: Text('Please select your registration type to continue')
                ),
              ),
              SizedBox(height: 45.0,),
              GreenButton(buttonTitle: 'Partners', onTap: (){
                //Navigator.pushNamed(context, routeName);
                print('partners clicked');
              },),
              SizedBox(height: 20.0,),
              GreenButton(buttonTitle: 'Students', onTap: (){
                Navigator.pushNamed(context, StudentRegistration.id);
                //print('students clicked');
              }),
              SizedBox(height: 20.0,),
              GreenButton(buttonTitle: 'Youth Corp Members', onTap: (){
                //Navigator.pushNamed(context, routeName);
                print('Youth Core Members clicked');
              }),
            ],
          ),)
      ),
    );
  }
}




