import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'dart:io';
import 'package:flutter_todo/components/curved_page_template.dart';
import 'package:progress_indicators/progress_indicators.dart';
import 'package:provider/provider.dart';
import 'package:flutter_todo/providers/auth.dart';
import 'package:flutter_todo/providers/user.dart';
import 'package:flutter_todo/utils/constants.dart';



enum UploadStatus {Uploading,BeforeUpload,AfterUpload}

UploadStatus _status =UploadStatus.BeforeUpload;

class Payment extends StatefulWidget {
  static final id = 'image_upload';



  @override
  _PaymentState createState() => _PaymentState();
}

class _PaymentState extends State<Payment> {

  File file;
  AuthProvider _provider;
  UserProvider _userProvider;
  String  _userName;
  String _userAvatar;


  @override
  void didChangeDependencies() {
    init(context);
    super.didChangeDependencies();

  }

  Future<void>init(context)  async{
//    _provider =  Provider.of<AuthProvider>(context);
   _userProvider =  Provider.of<UserProvider>(context);
   _userName= await _userProvider.getUserName();
   _userAvatar= await _userProvider.getUserAvatar();
   //print('paymant page');
   setState(() {});
  }




  @override
  Widget build(BuildContext context) {

    final userAvatarWidget =
    Center(
    child: CircleAvatar(
      backgroundColor: Colors.green,
      backgroundImage:  NetworkImage("$siteUrl/uploads/card_holders/card_holders$_userAvatar"),
      radius: MediaQuery.of(context).size.width/12,
    ));

    final consumer=  Consumer<UserProvider>(
      builder:(context, user, child)=>  Scaffold(
        //backgroundColor: Color(0xFF21BFBD),
        backgroundColor: Colors.green,
        //backgroundColor: Color(0xEEE),
//      appBar: AppBar(
//        title: const Text('Go Back',style: TextStyle(color: Colors.green),),
//        iconTheme: IconThemeData(color: Colors.green),
//        backgroundColor: Colors.white,
//
//      ),
        body: Container(
          //color: Colors.white,
            child: CurvedPageTemplate( titleBold: 'Card', titleLight: 'Payment',  curvedChild:
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                SizedBox(height: 30.0,),
                _userName!=null? Text( 'Hi, $_userName',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 18.0),) : Text(''),
                SizedBox(height: 5.0,),
                Container(
                  decoration: BoxDecoration(
                      color: Colors.grey[200],
                      borderRadius: BorderRadius.all(Radius.circular(25.0))
                  ),

                  padding: EdgeInsets.all(10.0),
                  margin: EdgeInsets.all(15.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[

                          _userAvatar!=null ? userAvatarWidget : Text(''),
                          SizedBox(height: 10.0,),

                          Container(child: Text("Things are looking great!! Toenjoy discounts from all our esteemed partners, you need your very own discount card. At N2,500 your discount card is valid for 1 year.",textAlign: TextAlign.justify,style: TextStyle(  fontWeight: FontWeight.w400,color: Colors.black,),)),


                    ],),),
                Text('Pay',style: TextStyle(
                    color: Colors.black,
                    fontSize: 20.0
                )),
                Center(
                  child: RichText(
                      text: TextSpan(
                        // set the default style for the children TextSpans
                          //style: Theme.of(context).textTheme.body1.copyWith(fontSize: 30),
                          children: [

                            TextSpan(
                                text: ' '
                            ),
                            TextSpan(
                                text: ' '
                            ),
                            TextSpan(
                              text: 'N',
                                style: TextStyle(
                                    color: Colors.green
                                )
                            ),
                            TextSpan(
                                text: '2,500',
                                style: TextStyle(
                                    color: Colors.green,
                                  fontSize: 50.0
                                )
                            ),

                          ]
                      )
                  ),
                ),
                Text('via',style: TextStyle(
                    color: Colors.black,
                    fontSize: 20.0
                )),

                SizedBox(height: 20.0,),
           Center(
             child: Row(
               mainAxisAlignment: MainAxisAlignment.center,
               children: <Widget>[
                 FlatButton(
                   color: Colors.green,
                   textColor: Colors.white,
                   onPressed: (){},
                   child:  Text('Card')  ,
                 ),
                 SizedBox(width: 10.0,),
                 FlatButton(
                   color: Colors.green,
                   textColor: Colors.white,
                   onPressed: (){showModalBottomSheet( context: context,builder:(context)=> BankInfoModal());},
                   child:  Text('Bank')  ,
                 ),
               ],
             ),
           )


              ],
            )

            )
        ),
      ),
    );

    return  consumer;
  }
}

class BankInfoModal extends StatelessWidget {
  const BankInfoModal({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Color(0xff757575),
      child: Container(
        decoration:BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(topRight:Radius.circular(20.0),topLeft:Radius.circular(20.0))
        ),
        height: MediaQuery.of(context).size.height/2,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(

            children: <Widget>[
              SizedBox(height: 20.0,),
              Padding(
                padding: const EdgeInsets.all(8.0),


                child:Text('Bank Information',style: TextStyle(color: Colors.black,fontSize: 30.0),)

              ),
              SizedBox(height: 20.0,),
              Container(
                padding: EdgeInsets.all(5),
                margin: EdgeInsets.all(0),
                decoration: BoxDecoration(
                  color: Colors.green,
                  borderRadius: BorderRadius.circular(20.0),
                  
                ),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      SizedBox(width: 30.0,),Text('ACCOUNT NAME -',style: TextStyle(fontWeight: FontWeight.bold,color: Colors.white),), Text('BRIDGE CONCEPT NIG LTD',style: TextStyle(color: Colors.white))

                    ],

                  ),
                ),
              ),
              SizedBox(height: 30.0,),
              Container(
                padding: EdgeInsets.all(5),
                margin: EdgeInsets.all(0),
                decoration: BoxDecoration(
                    color: Colors.green,
                   // borderRadius: BorderRadius.only(topLeft: Radius.circular(25),topRight: Radius.circular(25)),
                  borderRadius: BorderRadius.circular(20.0),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                    SizedBox(width: 30.0,) ,Text('Acct No-',style: TextStyle(fontWeight: FontWeight.bold,color: Colors.white),),Text(' 1020854761',style: TextStyle(color: Colors.white))

                  ],),
                ),
              ),
              SizedBox(height: 30.0,),
              Container(
                padding: EdgeInsets.all(5),
                margin: EdgeInsets.all(0),
                decoration: BoxDecoration(
                    color: Colors.green,
                    //borderRadius: BorderRadius.only(topLeft: Radius.circular(25),topRight: Radius.circular(25)),
                  borderRadius: BorderRadius.circular(20.0),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row( mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      SizedBox(width: 30.0,),Text('Bank:',style: TextStyle(fontWeight: FontWeight.bold,color: Colors.white),) ,Text(' UBA',style: TextStyle(color: Colors.white))
                  ],),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}




