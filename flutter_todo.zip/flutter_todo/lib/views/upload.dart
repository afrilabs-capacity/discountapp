import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'dart:io';
import 'dart:convert';
import 'package:flutter_todo/components/curved_page_template.dart';
import 'package:image_picker/image_picker.dart';
import 'package:progress_indicators/progress_indicators.dart';
import 'package:provider/provider.dart';
import 'package:flutter_todo/providers/auth.dart';
import 'package:flutter_todo/providers/user.dart';
import 'package:flutter_todo/services/uploadService.dart';
import 'package:flutter_todo/views/payment.dart';


enum UploadStatus {Uploading,BeforeUpload,AfterUpload}

UploadStatus _status =UploadStatus.BeforeUpload;

class UploadPassport extends StatefulWidget {
  static final id = 'image_upload';



  @override
  _UploadPassportState createState() => _UploadPassportState();
}

class _UploadPassportState extends State<UploadPassport> {

  File file;

  AuthProvider authProvider;

  UploadService uploadService;

  AuthProvider _provider;

 UserProvider _userProvider;

  String _userName;

  //apiService = ApiService(authProvider);


  initAuthProvider(context)  async{
    _provider =  Provider.of<AuthProvider>(context);
    _userProvider =  Provider.of<UserProvider>(context);
    _userName= await _userProvider.getUserName();
    setState(() {});

   //return _provider;
   // print(_)
  }

  void _choose() async {
    //_userProvider.changeString('wahala');
    file = await ImagePicker.pickImage(source: ImageSource.gallery,maxHeight: 300.0,
        maxWidth: 250.0,imageQuality: 100);
    setState(() {});
// file = await ImagePicker.pickImage(source: ImageSource.gallery);
  }

  Future<void> _upload()  async{
    if (file == null) return;

    setState(() {
      _status= UploadStatus.Uploading;
    });

    String base64Image = base64Encode(file.readAsBytesSync());
    String fileName = file.path.split("/").last;

    uploadService = UploadService(_provider);

   var  response = await  uploadService.uploadPassport(base64Image);
   if(response['success']){
     Map<String, dynamic> mappedResponse =jsonDecode(response['data']);
     await _userProvider.saveUserAvatar(mappedResponse['data']);
     Navigator.push(context, MaterialPageRoute(builder: (context)=>Payment()));
     //print("success  ${mappedResponse['data']}");

   }

  setState(() {
    _status= UploadStatus.AfterUpload;
  });

  }


  @override
  Widget build(BuildContext context) {

   initAuthProvider(context);

    return  Consumer<UserProvider>(
      builder:(context, user, child)=> Scaffold(
        //backgroundColor: Color(0xFF21BFBD),
        backgroundColor: Colors.green,
        //backgroundColor: Color(0xEEE),
//      appBar: AppBar(
//        title: const Text('Go Back',style: TextStyle(color: Colors.green),),
//        iconTheme: IconThemeData(color: Colors.green),
//        backgroundColor: Colors.white,
//
//      ),
        body: Container(
          //color: Colors.white,
            child: CurvedPageTemplate( titleBold: 'Upload', titleLight: 'Passport',  curvedChild:
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                _userName!=null? Text( 'Hi, $_userName',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 18.0),) : Text(''),
                SizedBox(height: 5.0,),
                Container(

                  decoration: BoxDecoration(
                      color: Colors.grey[200],
                    borderRadius: BorderRadius.all(Radius.circular(25.0))
                  ),

                  padding: EdgeInsets.all(10.0),
                  margin: EdgeInsets.all(15.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[

                  Text("You\'re almost done!! Please upload a clear front-facing image of yourself",textAlign: TextAlign.center,style: TextStyle(  fontWeight: FontWeight.w300,color: Colors.black,),),

                ],),),

                SizedBox(height: 20.0,),
                Stack(

                   children: <Widget>[
//                  RaisedButton(
//                    onPressed: _choose,
//                    child: Text('Choose Image'),
//                  ),

//                  RaisedButton(
//                    onPressed: _upload,
//                    child: Text('Upload Image'),
//                  ),

                     Center(

                       child: file == null
                           ? CircleAvatar( child: Text('PLease select image',style: TextStyle(color: Colors.black),), backgroundColor: Colors.grey[200], radius: MediaQuery.of(context).size.width/3,)
                           : new CircleAvatar(backgroundColor: Colors.green, backgroundImage: new FileImage(file), radius: MediaQuery.of(context).size.width/3,),
                     ),
                     _status!=UploadStatus.Uploading ?  Positioned(
                       left:MediaQuery.of(context).size.width-100,
                       top: MediaQuery.of(context).size.height-620,
                       child: CircleAvatar(
                         radius: 30,
                         backgroundColor: Colors.green,
                         child: IconButton(
                           icon: Icon(
                             Icons.add_a_photo,
                             color: Colors.white,
                           ),
                           onPressed:  _choose,
                         ),
                       ),

                     ) : SizedBox(),

                   ],
                 ),
                SizedBox(height: 20.0,),
                RaisedButton(
                  onPressed: _upload,
                  color: Colors.green,
                  child:  _status==UploadStatus.BeforeUpload ?  Text('Upload Image',style: TextStyle(color: Colors.white),) :
                  _status== UploadStatus.Uploading ?  JumpingText('Uploading...',style: TextStyle( color: Colors.white, fontSize: 20.0),) :
                  _status== UploadStatus.AfterUpload ? Text('Upload Image',style: TextStyle(color: Colors.white),) : '',

                ),
              ],
            )

            )
        ),
      ),
    );
  }
}




