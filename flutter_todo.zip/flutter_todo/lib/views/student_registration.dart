import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_todo/components/green_round_button.dart';
import 'package:flutter_todo/components/curved_page_template.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter_todo/utils/validate.dart';
import 'package:provider/provider.dart';
import 'package:flutter_todo/providers/auth.dart';
import 'package:flutter_todo/styles/styles.dart';
import 'package:intl/intl.dart';
import 'package:flutter_todo/models/state.dart';
import 'package:flutter_todo/components/header_green.dart';
import 'package:flutter_todo/views/upload.dart';
//import '';


enum Sex { MALE, FEMALE }


class StudentRegistration extends StatefulWidget {
  static final id = 'student_registration';
  @override
  _StudentRegistrationState createState() => _StudentRegistrationState();
}

class _StudentRegistrationState extends State<StudentRegistration> {

  /*global keys*/
  final GlobalKey<FormState> _formKey_0 = GlobalKey<FormState>();
  final GlobalKey<FormState> _formKey_1 = GlobalKey<FormState>();
  final GlobalKey<FormState> _formKey_2 = GlobalKey<FormState>();
  final GlobalKey<FormState> _formKey_3 = GlobalKey<FormState>();
  final _scaffoldKey = GlobalKey<ScaffoldState>();

  FocusNode myFocusNode;

  Map response = new Map();

  String message = '';



  //TextEditingController titleController = TextEditingController();
  TextEditingController firstNameController = TextEditingController();
  TextEditingController middleNameController = TextEditingController();
  TextEditingController lastNameController = TextEditingController();
  TextEditingController addressController = TextEditingController();
  //TextEditingController sexController = TextEditingController();
  TextEditingController cityController = TextEditingController();
  //TextEditingController stateController = TextEditingController();
  TextEditingController dobController = TextEditingController();
  //TextEditingController idTypeController = TextEditingController();
  TextEditingController idNumberController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  //TextEditingController regTypeController = TextEditingController();
  TextEditingController instituteSchoolController = TextEditingController();
  TextEditingController matriculationExamNumberController = TextEditingController();
  TextEditingController levelExpectedGraduationYearController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController passwordConfirmController = TextEditingController();







  String titleDropdownValue = 'Plese select title';

  List<String> titleList = ['Mr','Mrs'];

  List<String> idTypeList = ['International Passports','Driver\'s Licence','VOTERS\'S CARD','STUDENT ID Card'];

  List<String> sexList = ['Male','Female'];

  List<MyState> stateList = [

    MyState(id:1,state:'Abia State'),
    MyState(id:2,state: 'Abuja FCT'),
  MyState(id:3,state:'Adamawa State'),
  MyState(id:4,state:'Akwa Ibom State'),
  MyState(id:5,state:'Anambra State'),
  MyState(id:6,state:'Bauchi State'),
  MyState(id:7,state:'Bayelsa State'),
  MyState(id:8,state:'Benue State',),
  MyState(id:10,state:'Cross River State'),
  MyState(id:11,state:'Delta State'),
  MyState(id:12,state:'Ebonyi State'),
  MyState(id:13,state:'Edo State'),
  MyState(id:14,state:'Ekiti State'),
  MyState(id:15,state:'Enugu State'),
  MyState(id:16,state:'Gombe State'),
  MyState(id:17,state:'Imo State'),
  MyState(id:18,state:'Jigawa State'),
  MyState(id:19,state:'Kaduna State'),
  MyState(id:20,state:'Kano State'),
  MyState(id:21,state:'Katsina State'),
  MyState(id:22,state:'Kebbi State'),
  MyState(id:23,state:'Kogi State'),
  MyState(id:24,state:'Kwara State'),
  MyState(id:25,state:'Lagos State'),
  MyState(id:26,state:'Nasarawa State'),
  MyState(id:27,state:'Niger State'),
  MyState(id:28,state:'Ogun State'),
  MyState(id:29,state:'Ondo State'),
  MyState(id:30,state:'Osun State'),
  MyState(id:31,state:'Oyo State'),
  MyState(id:32,state:'Plateau State'),
  MyState(id:33,state:'Rivers State'),
  MyState(id:34,state:'Sokoto State'),
  MyState(id:35,state:'Taraba State'),
  MyState(id:36,state:'Yobe State'),
  MyState(id:37,state:'Zamfara State'),

  ];

  /*selects*/
  String selectedTitle;
  String selectedIdType;
  String selectedState;
  String selectedSex;

  /*date instance*/
  DateTime selectedDate = DateTime.now();

  /*date format instance*/
  DateFormat dateFormat = DateFormat("d-MM-yyyy");

  /*select field validation*/
  String titleValidation='';
  String idTypeValidation='';
  String stateValidation='';


    Future <void> submit() async {
      print('contacting registration server');
    if ( formValidationComplete()) {


      response = await Provider.of<AuthProvider>(context)
          .register(  selectedTitle, firstNameController.text, middleNameController.text,lastNameController.text,addressController.text, selectedSex,cityController.text ,selectedState ,dobController.text ,selectedIdType ,idNumberController.text , emailController.text ,  phoneController.text ,'student', instituteSchoolController.text , matriculationExamNumberController.text ,  levelExpectedGraduationYearController.text, passwordController.text,  passwordConfirmController.text);
      if (response['success']) {
        //Navigator.pop(context);
        final snackBar = SnackBar(content: Text(response['message']));
        _scaffoldKey.currentState.showSnackBar(snackBar) ;
        Navigator.push(context,MaterialPageRoute(builder: (context)=>UploadPassport()));
      } else {
        setState(() {

          if(response['errors']==null){
            final snackBar = SnackBar(content: Text(response['message']));
            _scaffoldKey.currentState.showSnackBar(snackBar) ;
          } //message = response['message'];
          else
            {
              //print('errors are in a list');
              _showModal();
              // print(getApiErrors());

            }

        });
      }
      //print(response);
    }
  }




  List<Padding> getApiErrors(){
      List<Widget> apiErrors=[];
    Map errors=response['errors'];
    //print(errors['first_name']);
    errors.forEach((key,value){
      apiErrors.add(Padding(
        padding: const EdgeInsets.all(8.0),
        child: Text(errors[key].toString(),style: TextStyle(color: Colors.red),),
      ));
      //print(value);
    });

    return apiErrors;

  }

  Widget buildBottomSheet(BuildContext context) =>Container(
    color: Color(0xff757575),
    child: Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
        topLeft: Radius.circular(20.0),
          topRight: Radius.circular(20.0)
        )
      ),
      child: ListView(
        children: getApiErrors(),
      ),

    ),
  );
  
  void _showModal(){
      showModalBottomSheet(context: context, builder: buildBottomSheet);
  }



  Future<Null> _selectDate(BuildContext context) async {
    final DateTime picked = await showDatePicker(
        builder: (BuildContext context, Widget child) {
          return Theme(
            data: ThemeData.light().copyWith(
                //primarySwatch: buttonTextColor,//OK/Cancel button text color
                primaryColor: Colors.green,//Head background
                accentColor:  Colors.green,

              colorScheme: ColorScheme.light(primary: Colors.green),
              buttonTheme: ButtonThemeData(
                  textTheme: ButtonTextTheme.primary
              ),
              //dialogBackgroundColor: Colors.white,//Background color
            ),
            child: child,
          );
        },
        context: context,
        initialDate: selectedDate,
        firstDate: DateTime(1965, 8),
        lastDate: DateTime(2101),


    );

    FocusScope.of(context).requestFocus(myFocusNode);

    if (picked != null && picked != selectedDate)
      setState(() {
        selectedDate = picked;
        dobController.text=dateFormat.format(selectedDate);
        print(selectedDate);
        //dobController.f
      });
  }



  List buildSteps(){
    List<Step> steps = [];
     steps.add( Step(
      isActive: false,
      state: stepStateMapping[0],
      title: const Text('Bio Information'),
      content: Form(
        autovalidate: false,
        key: _formKey_0,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            DropdownButton<String>(
              underline: Container(color:dropDownValidation_0, height:1.0),
              hint: Text('Please select title',style: TextStyle(color: Colors.black)),
              value: selectedTitle,
              items: titleList.map<DropdownMenuItem<String>>( (String value)=> DropdownMenuItem<String>(child: Text(value,style: TextStyle(color: Colors.black),),value:value ,)  ).toList(),
              //DropdownMenuItem(child: Text('USD',style: TextStyle(color: Colors.black),),value:'USD' ,),

              onChanged:(value){

                setState(() {
                  selectedTitle=value;
                  validateTitleField();
                  validateIdTypeField();
                });
              }

            ),
//            Text(titleValidation,style: TextStyle(color:
//            Colors.red),),
            TextFormField(
              controller: firstNameController,
              decoration: Styles.flatFormFields.copyWith(labelText: 'FIRST NAME',focusColor: Colors.pink),
              // The validator receives the text that the user has entered.
              validator: (value) {
                //email = value.trim();
                return Validate.requiredField(value,'First Name required');
              },
              //style: TextStyle(fontWeight: FontWeight.w100,color: Colors.black),
            ),
            TextFormField(
              controller: middleNameController,
              decoration: Styles.flatFormFields.copyWith(labelText: 'MIDDLE NAME',focusColor: Colors.pink),
              // The validator receives the text that the user has entered.
              validator: (value) {
                //email = value.trim();
                return Validate.requiredField(value,'Middle Name required');
              },
            ),

            TextFormField(
              controller: lastNameController,
              decoration: Styles.flatFormFields.copyWith(labelText: 'LAST NAME',focusColor: Colors.pink),
              // The validator receives the text that the user has entered.
              validator: (value) {
                //email = value.trim();
                return Validate.requiredField(value,'Last Name required');
              },
            ),

            InkWell(
              onTap: () {
                _selectDate(context);   // Call Function that has showDatePicker()
              },
              child: IgnorePointer(
                child: new TextFormField(
                  focusNode: myFocusNode,
                  controller: dobController,
                  decoration: new InputDecoration(hintText: 'DATE OF BIRTH'),
                  maxLength: 10,
                  validator: (value) {
                    //email = value.trim();
                    return Validate.requiredField(value,'Date of birth required');
                  },
                  //onSaved: (String val) {},
                ),
              ),
            ),
            DropdownButton<String>(
                underline: Container(color:dropDownValidation_3, height:1.0),
                hint: Text('Please select sex',style: TextStyle(color: Colors.black)),
                value: selectedSex,
                items: sexList.map<DropdownMenuItem<String>>( (String value)=> DropdownMenuItem<String>(child: Text(value,style: TextStyle(color: Colors.black),),value:value ,)  ).toList(),
                //DropdownMenuItem(child: Text('USD',style: TextStyle(color: Colors.black),),value:'USD' ,),

                onChanged:(value){

                  setState(() {
                    selectedSex=value;
                    validateSexField();

                  });
                }

            ),

          ],
        ),
      ),
    ) );


    steps.add( Step(
    isActive: false,
    state: stepStateMapping[1],
    title: const Text('Identification'),
    content: Form(
      autovalidate: false,
      key: _formKey_1,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
      DropdownButton<String>(
        underline: Container(color:dropDownValidation_1, height:1.0),
                            hint: Text('Please select ID Type',style: TextStyle(color: Colors.black)),
                            value: selectedIdType,
                            items: idTypeList.map<DropdownMenuItem<String>>( (String value)=> DropdownMenuItem<String>(child: Text(value,style: TextStyle(color: Colors.black),),value:value ,)  ).toList(),
                            //DropdownMenuItem(child: Text('USD',style: TextStyle(color: Colors.black),),value:'USD' ,),

                            onChanged:(value){

                              setState(() {
                                selectedIdType=value;
                                validateIdTypeField();
                              });
                            } ,

                          ),
//                          Text(idTypeValidation,style: TextStyle(color:
//                          Colors.red),),
                      SizedBox(height: 5.0,),

                          TextFormField(
                            controller: idNumberController,
                            decoration: Styles.flatFormFields.copyWith(labelText: 'ID Number',focusColor: Colors.pink),
                            // The validator receives the text that the user has entered.
                            validator: (value) {
                              //email = value.trim();
                              return Validate.requiredField(value,'ID Number required');
                            },
                            //style: TextStyle(fontWeight: FontWeight.w100,color: Colors.black),
                          ),

        TextFormField(
          controller: addressController,
          decoration: Styles.flatFormFields.copyWith(labelText: 'ADRESS',focusColor: Colors.pink),
          // The validator receives the text that the user has entered.
          validator: (value) {
            //email = value.trim();
            return Validate.requiredField(value,'Adress required');
          },
          //style: TextStyle(fontWeight: FontWeight.w100,color: Colors.black),
        ),
        TextFormField(
          keyboardType: TextInputType.number,
          controller: phoneController,
          decoration: Styles.flatFormFields.copyWith(labelText: 'PHONE',focusColor: Colors.pink,),
          // The validator receives the text that the user has entered.
//                                    validator: (value) {
//                                      //email = value.trim();
//                                      return Validate.requiredField(value,'Enter Valid Phone Number');
//                                    },
          //style: TextStyle(fontWeight: FontWeight.w100,color: Colors.black),
        ),
        SizedBox(height: 10.0,),
        DropdownButton<String>(
          underline: Container(color:dropDownValidation_2, height:1.0),
          hint: Text('Please select State',style: TextStyle(color: Colors.black)),
          value: selectedState,
          items: stateList.map<DropdownMenuItem<String>>( (value)=> DropdownMenuItem<String>(child:
          Text(value.state,style: TextStyle(color: Colors.black),),value:value.id.toString(),)  ).toList(),
          //DropdownMenuItem(child: Text('USD',style: TextStyle(color: Colors.black),),value:'USD' ,),

          onChanged:(value){

            setState(() {
              selectedState=value;
              validateStateField();
            });
          } ,

        ),SizedBox(height: 5.0,),
        TextFormField(

          controller:cityController ,
          decoration: Styles.flatFormFields.copyWith(labelText: 'CITY',focusColor: Colors.pink,),
          // The validator receives the text that the user has entered.
                                    validator: (value) {
                                      //email = value.trim();
                                      return Validate.requiredField(value,'City required');
                                    },
          //style: TextStyle(fontWeight: FontWeight.w100,color: Colors.black),
        ),

                          SizedBox(height: 5.0,),
//                                  Container(
//                                    alignment: Alignment.centerLeft,
//                                    child: Text(
//                                        'SEX',style: TextStyle(fontWeight: FontWeight.bold,color: Colors.grey,fontSize: 17.0)
//                                    ),
//                                  ),

      ],
      ),
    ),
    ) );


    steps.add( Step(
    isActive: false,
    state:  stepStateMapping[2],
    title: const Text('Education'),
    content: Form(
      autovalidate: false,
      key: _formKey_2,
      child: Column(
      children: <Widget>[

//        Text(stateValidation,style: TextStyle(color:
//        Colors.red),),

        TextFormField(
          controller: instituteSchoolController,
          decoration: Styles.flatFormFields.copyWith(labelText: 'INSTITUTE / SCHOOL ATTENDED',focusColor: Colors.pink,),
          // The validator receives the text that the user has entered.
          validator: (value) {
            //email = value.trim();
            return Validate.requiredField(value,'Institute / School required');
          },
          //style: TextStyle(fontWeight: FontWeight.w100,color: Colors.black),
        ),
//

                          SizedBox(height: 10.0,),
                          TextFormField(
                            controller: levelExpectedGraduationYearController,
                            decoration: Styles.flatFormFields.copyWith(labelText: 'GRADUATION YEAR / LEVEL',focusColor: Colors.pink,),
                            // The validator receives the text that the user has entered.
                                    validator: (value) {
                                      //email = value.trim();
                                      return Validate.requiredField(value,'Level / Graduation Year required');
                                    },
                            //style: TextStyle(fontWeight: FontWeight.w100,color: Colors.black),
                          ),

        TextFormField(
          controller: matriculationExamNumberController,
          decoration: Styles.flatFormFields.copyWith(labelText: 'MATRICULATION NUMBER',focusColor: Colors.pink,),
          // The validator receives the text that the user has entered.
          validator: (value) {
            //email = value.trim();
            return Validate.requiredField(value,'Matriculation Number required');
          },
          //style: TextStyle(fontWeight: FontWeight.w100,color: Colors.black),
        ),
      ],
      ),
    ),
    ) );

    steps.add( Step(
      isActive: false,
      state:  stepStateMapping[3],
      title: const Text('Authorization'),
      content: Form(
        autovalidate: false,
        key: _formKey_3,
        child: Column(
          children: <Widget>[

//        Text(stateValidation,style: TextStyle(color:
//        Colors.red),),
            SizedBox(height: 8.0,),

//

            SizedBox(height: 10.0,),


            TextFormField(
              keyboardType: TextInputType.emailAddress,
              controller: emailController,
              decoration: Styles.flatFormFields.copyWith(labelText: 'EMAIL',focusColor: Colors.pink,),
              // The validator receives the text that the user has entered.
              validator: (value) {
                //email = value.trim();
                return Validate.validateEmail(value);
              },
              //style: TextStyle(fontWeight: FontWeight.w100,color: Colors.black),
            ),

            TextFormField(
              obscureText: true,
              controller: passwordController,
              decoration: Styles.flatFormFields.copyWith(labelText: 'PASSWORD',focusColor: Colors.pink,),
              // The validator receives the text that the user has entered.
              validator: (value) {
                //email = value.trim();
                return Validate.passwordValidate(value);
              },
              //style: TextStyle(fontWeight: FontWeight.w100,color: Colors.black),
            ),
            SizedBox(height: 10.0,),
            TextFormField(
              obscureText: true,
              controller: passwordConfirmController,
              decoration: Styles.flatFormFields.copyWith(labelText: 'PASSWORD CONFIRM',focusColor: Colors.pink,),
              // The validator receives the text that the user has entered.
              validator: (value) {
                //email = value.trim();
                return Validate.passwordConfirmValidate(value, passwordController.text);
              },
              //style: TextStyle(fontWeight: FontWeight.w100,color: Colors.black),
            ),
          ],
        ),
      ),
    ) );

    return steps;

  }


  List<StepState> _listState;



  void validateTitleField(){
    if(selectedTitle==null){
      setState(() {
        dropDownValidation_0= Colors.red;
      });
    }else{
      setState(() {
        dropDownValidation_0= Colors.grey;
      });

    }
  }

  void validateIdTypeField(){
    if(selectedIdType==null){
      setState(() {
        dropDownValidation_1= Colors.red;
      });
    }else{

      setState(() {
        dropDownValidation_1= Colors.grey;
      });

    }

  }

  void validateStateField(){
    if(selectedState==null){
      setState(() {
        dropDownValidation_2= Colors.red;
      });
    }else{
      setState(() {
        dropDownValidation_2= Colors.grey;
      });

    }

  }

  void validateSexField(){
    if(selectedSex==null){
      setState(() {
        dropDownValidation_3= Colors.red;
      });
    }else{
      setState(() {
        dropDownValidation_3= Colors.grey;
      });

    }

  }

  @override
  void initState() {

    _listState = [
      StepState.indexed,
      StepState.editing,
      StepState.complete,
      StepState.error,
    ];

    firstNameController.text = "Attah";
    middleNameController.text = "M";
    lastNameController.text = "Braimah";
    addressController.text = "Plot b56 phase 2 site Kubwa Abuja";
    cityController.text = "Kubwa";
    dobController.text = "26-03-2020";
    idNumberController.text = "CPA/344/2004";
    emailController.text = "braimahjake@gmail.com";
    phoneController.text = "07036066056";
    instituteSchoolController.text = "Benue State University";
    matriculationExamNumberController.text = "GYGSFET/33737";
    levelExpectedGraduationYearController .text= "2018";
    passwordController.text = "123456";
    passwordConfirmController.text = "123456";

    //selectedTitle="Mr";
    //selectedIdType="NATIONAI ID CARD";
    //selectedSex="Male";


    myFocusNode = FocusNode();
    super.initState();
  }


  /* Set the state of our form steps complete / editing / error / disabled */
  StepState stepState_0= StepState.editing;
  StepState stepState_1=StepState.disabled;
  StepState stepState_2=StepState.disabled;
  StepState stepState_3=StepState.disabled;

  /* Set the color of dropDown button based on validation*/
  Color dropDownValidation_0= Colors.grey;
  Color dropDownValidation_1= Colors.grey;
  Color dropDownValidation_2= Colors.grey;
  Color dropDownValidation_3= Colors.grey;

 /* Set form completion states*/
  bool stepComplete_0=false;
  bool stepComplete_1=false;
  bool stepComplete_2=false;
  bool stepComplete_3=false;



 int currentStep = 0;

  bool complete = false;


  final Map<int, StepState> stepStateMapping = {
    0:StepState.editing,
    1:StepState.disabled,
    2:StepState.disabled,
    3:StepState.disabled
  };

  final Map<int, bool> stepCompleteMapping = {
    0:false,
    1:false,
    2:false,
    3:false
  };


 bool validateSelectsBasedOnStep(){

   if(currentStep==0){

     if(selectedTitle==null || selectedSex==null){
       return false;
     }

     return true;

   }


   if(currentStep==1){

     if(selectedIdType==null || selectedState==null){
       return false;
     }

     return true;

   }

   return true;


 }

 bool validateSteps(){

     //int formKey;

   print(currentStep);
    final Map<int, GlobalKey<FormState>> stepKeyMapping = {
      0:_formKey_0,
      1:_formKey_1,
      2:_formKey_2,
      3:_formKey_3
    };

    validateTitleField();
    validateIdTypeField();
    validateStateField();
    validateSexField();

    if (!stepKeyMapping[currentStep].currentState.validate() ||  validateSelectsBasedOnStep()==false) {
      stepCompleteMapping[currentStep]=false;
      stepStateMapping[currentStep]=StepState.error;
      return false;
    }
   stepStateMapping[currentStep]=StepState.complete;
   stepStateMapping[currentStep+1]=StepState.editing;
   stepCompleteMapping[currentStep]=true;
    return true;
   }

  bool formValidationComplete(){

    bool stepsComplete=false;

    stepCompleteMapping.forEach((index,value)=> stepCompleteMapping[index]==true ? stepsComplete=true :  stepsComplete=false);

    if(stepsComplete)
      return true;
    else
      return false;
  }

  next() {
    validateSteps() ? 
      //currentStep + 1 != 4 ? goTo(currentStep + 1) : setState(() => complete = true);
    currentStep  != buildSteps().length-1  ? currentStep++ : setState(() => complete = true) : setState(() => complete = false)   ;
   if(currentStep==3 && formValidationComplete()) submit();
  }

  cancel() {
   print(currentStep);
    if (currentStep > 0) {
      //goTo(currentStep - 1);
      setState(() {
        stepStateMapping[currentStep]=StepState.disabled;
        currentStep--;
        stepStateMapping[currentStep]=StepState.editing;
      });

    }
  }

  goTo(int step) {
    //setState(() => currentStep = step);
    setState(() {
      if(currentStep!=step){
        stepCompleteMapping[currentStep]==true ? stepStateMapping[currentStep]=StepState.complete : stepStateMapping[currentStep]=StepState.disabled;
        stepStateMapping[step]=StepState.editing;
        currentStep = step;
      }

      //stepStateMapping[currentStep]=StepState.editing;
    });

  }






  @override
  Widget build(BuildContext context) {

    return new Scaffold(
        key: _scaffoldKey,
        resizeToAvoidBottomInset: true,
        //backgroundColor: Color(0xFF21BFBD),
        backgroundColor: Colors.white,
        body: Builder(
              builder: (context) =>
           Theme(
            data: ThemeData(
                primaryColor: Colors.green,
              iconTheme: IconThemeData(
                color: Colors.green
              )
            ),
            child: Column(children: <Widget>[
              Container(
                color:Colors.green,
                child: HeaderTemplate(
                  titleBold: 'Registration (students)',titleLight: '',
                ),
              ),

              Expanded(
                child: Stepper(
                  controlsBuilder:
                      (BuildContext context, {VoidCallback onStepContinue, VoidCallback onStepCancel}) {
                    return Padding(
                      padding: const EdgeInsets.symmetric( horizontal: 10.0, vertical: 10.0),
                      child: StepControlButtons(currentStep: currentStep,onStepContinue: onStepContinue,onStepCancel: onStepCancel,),
                    );
                  },
                  type: StepperType.vertical,
                  currentStep: currentStep,
                  onStepContinue: next,
                  onStepTapped: (step) => goTo(step),
                  onStepCancel: cancel,
                  steps: buildSteps(),
                ),
              ),
            ]),
          ),
        ));
 }

  @override
  void dispose() {

    //titleController.dispose();
    firstNameController.dispose();
    middleNameController.dispose();
    lastNameController.dispose();
    idNumberController.dispose();
    addressController.dispose();
    //sexController.dispose();
    cityController.dispose();
    //stateController.dispose();
    dobController.dispose();
    //idTypeController.dispose();
    phoneController.dispose();
    emailController.dispose();
    //regTypeController.dispose();
    instituteSchoolController.dispose();
    matriculationExamNumberController.dispose();
    levelExpectedGraduationYearController.dispose();
    passwordController.dispose();
    passwordConfirmController.dispose();
    myFocusNode.dispose();
    super.dispose();
 }



}

class StepControlButtons extends StatelessWidget {
  const StepControlButtons({
    Key key,
    @required this.currentStep,this.onStepContinue, this.onStepCancel
  }) : super(key: key);

  final int currentStep;
  final Function onStepContinue;
  final Function onStepCancel;

  @override
  Widget build(BuildContext context) {


   return   currentStep!=0 ? Row(

      children: <Widget>[

           FlatButton(
            color: Colors.green,
            textColor: Colors.white,
            onPressed: onStepContinue,
            child:  currentStep==3 ?  const Text('REGISTER') : const Text('CONTINUE')  ,
          ),

        FlatButton(
          onPressed: onStepCancel,
          child:  currentStep==0 ? const Text('')  : const Text('PREVIOUS'),
        ),
      ],
     ) :
   Row(
     children: <Widget>[
   Expanded(
     child: FlatButton(
       color: Colors.green,
       textColor: Colors.white,
       onPressed: onStepContinue,
       child:  Text('CONTINUE')  ,
     ),
   ),
     ],
   );





  }
}

