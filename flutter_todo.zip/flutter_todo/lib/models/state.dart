
class MyState{
  int id;
  String state;
  MyState({this.id,this.state});
}