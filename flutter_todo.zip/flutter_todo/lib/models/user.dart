class User {
  final String email;
  final String name;
  final String token;

  User({ this.email, this.name, this.token });
}